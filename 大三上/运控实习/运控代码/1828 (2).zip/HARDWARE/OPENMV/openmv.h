#ifndef __OPENMV_H
#define __OPENMV_H

#include "stdio.h"	
#include "sys.h" 
extern double getx1;
extern double getx2;
extern double gety1;
extern double gety2;
void openmv_init(u32 bound);
float openmv_sort(void);






#endif