#ifndef __IIC_H__
#define __IIC_H__
void KeyScan_Test(void);
void Key_ISR(void);
void Key_Scan(void);
#endif