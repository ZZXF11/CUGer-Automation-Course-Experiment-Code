//BMP H file

extern const unsigned char microphone[];

