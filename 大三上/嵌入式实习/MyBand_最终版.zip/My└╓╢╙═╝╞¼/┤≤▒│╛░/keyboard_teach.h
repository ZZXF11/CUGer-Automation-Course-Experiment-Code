//BMP H file

extern const unsigned char keyboard_teach[];

