//BMP H file

extern const unsigned char microphonemini[];

