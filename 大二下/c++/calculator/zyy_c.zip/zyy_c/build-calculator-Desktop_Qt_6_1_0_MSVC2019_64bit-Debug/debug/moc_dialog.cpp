/****************************************************************************
** Meta object code from reading C++ file 'dialog.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.1.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../calculator/dialog.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.1.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Dialog_t {
    const uint offsetsAndSize[90];
    char stringdata0[693];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_Dialog_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_Dialog_t qt_meta_stringdata_Dialog = {
    {
QT_MOC_LITERAL(0, 6), // "Dialog"
QT_MOC_LITERAL(7, 15), // "on_num1_clicked"
QT_MOC_LITERAL(23, 0), // ""
QT_MOC_LITERAL(24, 15), // "on_num2_clicked"
QT_MOC_LITERAL(40, 15), // "on_num3_clicked"
QT_MOC_LITERAL(56, 15), // "on_num4_clicked"
QT_MOC_LITERAL(72, 15), // "on_num5_clicked"
QT_MOC_LITERAL(88, 15), // "on_num6_clicked"
QT_MOC_LITERAL(104, 15), // "on_num7_clicked"
QT_MOC_LITERAL(120, 15), // "on_num8_clicked"
QT_MOC_LITERAL(136, 15), // "on_num9_clicked"
QT_MOC_LITERAL(152, 15), // "on_num0_clicked"
QT_MOC_LITERAL(168, 16), // "on_point_clicked"
QT_MOC_LITERAL(185, 15), // "on_plus_clicked"
QT_MOC_LITERAL(201, 13), // "on_pi_clicked"
QT_MOC_LITERAL(215, 14), // "on_sin_clicked"
QT_MOC_LITERAL(230, 14), // "on_cos_clicked"
QT_MOC_LITERAL(245, 14), // "on_tan_clicked"
QT_MOC_LITERAL(260, 15), // "on_asin_clicked"
QT_MOC_LITERAL(276, 15), // "on_acos_clicked"
QT_MOC_LITERAL(292, 15), // "on_atan_clicked"
QT_MOC_LITERAL(308, 15), // "on_lkuo_clicked"
QT_MOC_LITERAL(324, 15), // "on_rkuo_clicked"
QT_MOC_LITERAL(340, 17), // "on_gantan_clicked"
QT_MOC_LITERAL(358, 14), // "on_min_clicked"
QT_MOC_LITERAL(373, 14), // "on_mul_clicked"
QT_MOC_LITERAL(388, 14), // "on_div_clicked"
QT_MOC_LITERAL(403, 16), // "on_qiuyu_clicked"
QT_MOC_LITERAL(420, 18), // "on_pinfang_clicked"
QT_MOC_LITERAL(439, 18), // "on_kaifang_clicked"
QT_MOC_LITERAL(458, 15), // "on_back_clicked"
QT_MOC_LITERAL(474, 14), // "on_cle_clicked"
QT_MOC_LITERAL(489, 14), // "on_equ_clicked"
QT_MOC_LITERAL(504, 14), // "on_clc_clicked"
QT_MOC_LITERAL(519, 13), // "on_ce_clicked"
QT_MOC_LITERAL(533, 18), // "on_zhengfu_clicked"
QT_MOC_LITERAL(552, 15), // "on_qlog_clicked"
QT_MOC_LITERAL(568, 14), // "on_qln_clicked"
QT_MOC_LITERAL(583, 17), // "on_daoshu_clicked"
QT_MOC_LITERAL(601, 13), // "on_em_clicked"
QT_MOC_LITERAL(615, 15), // "on_time_clicked"
QT_MOC_LITERAL(631, 14), // "on_red_clicked"
QT_MOC_LITERAL(646, 15), // "on_blue_clicked"
QT_MOC_LITERAL(662, 16), // "on_black_clicked"
QT_MOC_LITERAL(679, 13) // "on_qe_clicked"

    },
    "Dialog\0on_num1_clicked\0\0on_num2_clicked\0"
    "on_num3_clicked\0on_num4_clicked\0"
    "on_num5_clicked\0on_num6_clicked\0"
    "on_num7_clicked\0on_num8_clicked\0"
    "on_num9_clicked\0on_num0_clicked\0"
    "on_point_clicked\0on_plus_clicked\0"
    "on_pi_clicked\0on_sin_clicked\0"
    "on_cos_clicked\0on_tan_clicked\0"
    "on_asin_clicked\0on_acos_clicked\0"
    "on_atan_clicked\0on_lkuo_clicked\0"
    "on_rkuo_clicked\0on_gantan_clicked\0"
    "on_min_clicked\0on_mul_clicked\0"
    "on_div_clicked\0on_qiuyu_clicked\0"
    "on_pinfang_clicked\0on_kaifang_clicked\0"
    "on_back_clicked\0on_cle_clicked\0"
    "on_equ_clicked\0on_clc_clicked\0"
    "on_ce_clicked\0on_zhengfu_clicked\0"
    "on_qlog_clicked\0on_qln_clicked\0"
    "on_daoshu_clicked\0on_em_clicked\0"
    "on_time_clicked\0on_red_clicked\0"
    "on_blue_clicked\0on_black_clicked\0"
    "on_qe_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Dialog[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      43,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  272,    2, 0x08,    0 /* Private */,
       3,    0,  273,    2, 0x08,    1 /* Private */,
       4,    0,  274,    2, 0x08,    2 /* Private */,
       5,    0,  275,    2, 0x08,    3 /* Private */,
       6,    0,  276,    2, 0x08,    4 /* Private */,
       7,    0,  277,    2, 0x08,    5 /* Private */,
       8,    0,  278,    2, 0x08,    6 /* Private */,
       9,    0,  279,    2, 0x08,    7 /* Private */,
      10,    0,  280,    2, 0x08,    8 /* Private */,
      11,    0,  281,    2, 0x08,    9 /* Private */,
      12,    0,  282,    2, 0x08,   10 /* Private */,
      13,    0,  283,    2, 0x08,   11 /* Private */,
      14,    0,  284,    2, 0x08,   12 /* Private */,
      15,    0,  285,    2, 0x08,   13 /* Private */,
      16,    0,  286,    2, 0x08,   14 /* Private */,
      17,    0,  287,    2, 0x08,   15 /* Private */,
      18,    0,  288,    2, 0x08,   16 /* Private */,
      19,    0,  289,    2, 0x08,   17 /* Private */,
      20,    0,  290,    2, 0x08,   18 /* Private */,
      21,    0,  291,    2, 0x08,   19 /* Private */,
      22,    0,  292,    2, 0x08,   20 /* Private */,
      23,    0,  293,    2, 0x08,   21 /* Private */,
      24,    0,  294,    2, 0x08,   22 /* Private */,
      25,    0,  295,    2, 0x08,   23 /* Private */,
      26,    0,  296,    2, 0x08,   24 /* Private */,
      27,    0,  297,    2, 0x08,   25 /* Private */,
      28,    0,  298,    2, 0x08,   26 /* Private */,
      29,    0,  299,    2, 0x08,   27 /* Private */,
      30,    0,  300,    2, 0x08,   28 /* Private */,
      31,    0,  301,    2, 0x08,   29 /* Private */,
      32,    0,  302,    2, 0x08,   30 /* Private */,
      33,    0,  303,    2, 0x08,   31 /* Private */,
      34,    0,  304,    2, 0x08,   32 /* Private */,
      35,    0,  305,    2, 0x08,   33 /* Private */,
      36,    0,  306,    2, 0x08,   34 /* Private */,
      37,    0,  307,    2, 0x08,   35 /* Private */,
      38,    0,  308,    2, 0x08,   36 /* Private */,
      39,    0,  309,    2, 0x08,   37 /* Private */,
      40,    0,  310,    2, 0x08,   38 /* Private */,
      41,    0,  311,    2, 0x08,   39 /* Private */,
      42,    0,  312,    2, 0x08,   40 /* Private */,
      43,    0,  313,    2, 0x08,   41 /* Private */,
      44,    0,  314,    2, 0x08,   42 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Dialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Dialog *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_num1_clicked(); break;
        case 1: _t->on_num2_clicked(); break;
        case 2: _t->on_num3_clicked(); break;
        case 3: _t->on_num4_clicked(); break;
        case 4: _t->on_num5_clicked(); break;
        case 5: _t->on_num6_clicked(); break;
        case 6: _t->on_num7_clicked(); break;
        case 7: _t->on_num8_clicked(); break;
        case 8: _t->on_num9_clicked(); break;
        case 9: _t->on_num0_clicked(); break;
        case 10: _t->on_point_clicked(); break;
        case 11: _t->on_plus_clicked(); break;
        case 12: _t->on_pi_clicked(); break;
        case 13: _t->on_sin_clicked(); break;
        case 14: _t->on_cos_clicked(); break;
        case 15: _t->on_tan_clicked(); break;
        case 16: _t->on_asin_clicked(); break;
        case 17: _t->on_acos_clicked(); break;
        case 18: _t->on_atan_clicked(); break;
        case 19: _t->on_lkuo_clicked(); break;
        case 20: _t->on_rkuo_clicked(); break;
        case 21: _t->on_gantan_clicked(); break;
        case 22: _t->on_min_clicked(); break;
        case 23: _t->on_mul_clicked(); break;
        case 24: _t->on_div_clicked(); break;
        case 25: _t->on_qiuyu_clicked(); break;
        case 26: _t->on_pinfang_clicked(); break;
        case 27: _t->on_kaifang_clicked(); break;
        case 28: _t->on_back_clicked(); break;
        case 29: _t->on_cle_clicked(); break;
        case 30: _t->on_equ_clicked(); break;
        case 31: _t->on_clc_clicked(); break;
        case 32: _t->on_ce_clicked(); break;
        case 33: _t->on_zhengfu_clicked(); break;
        case 34: _t->on_qlog_clicked(); break;
        case 35: _t->on_qln_clicked(); break;
        case 36: _t->on_daoshu_clicked(); break;
        case 37: _t->on_em_clicked(); break;
        case 38: _t->on_time_clicked(); break;
        case 39: _t->on_red_clicked(); break;
        case 40: _t->on_blue_clicked(); break;
        case 41: _t->on_black_clicked(); break;
        case 42: _t->on_qe_clicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject Dialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_Dialog.offsetsAndSize,
    qt_meta_data_Dialog,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Dialog_t

, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *Dialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Dialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Dialog.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int Dialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 43)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 43;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 43)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 43;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
